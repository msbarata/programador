class Pessoa:
    #atributos da classe
    __contador_pessoas = 0
    #Método da classe que mostra o contador de pessoas
    #Aplicação do decorador Static Method
    @staticmethod
    def mostra_ctrpessoas():
        return Pessoa.__contador_pessoas
    
    #Parte da classe quanto aos objetos
    #Construtor
    def __init__(self, nome, idade, nif):
        # atributo nome privado
        self.__nome = nome
        self.idade = idade
        self._nif = nif # O atributo passou a estar protegido: só obj tipo Pessoa e EMpregado pode aceder
        Pessoa.__contador_pessoas += 1 #Incrementa 1 ao contador de pessoas da classe
    #Destrutor
    def __del__(self):
        #print(f"A pessoa {self.__nome} foi apagada")
        Pessoa.__contador_pessoas -= 1 #Decrementar o contador de Pessoas


    #Métodos da classe gets e sets dos atributos dos objetos do tipo classe Pessoa
    def get_nome(self):
        return self.__nome
    def set_nome(self,novo_nome):
        self.__nome = novo_nome
        return self.__nome

    def get_idade(self):
        return self.idade
    def set_idade(self,nova_idade):
        self.idade = nova_idade
        return self.idade
    
    #acesso interno ao atributo protegido pela próprio classe ou suas subclasses através dos métodos
    def get_nif(self):
        return self._nif
    def set_nif(self,novo_nif):
        self._nif = novo_nif
        

class Empregado(Pessoa):
    #construtor da classe Empregado
    def __init__(self, nome, idade, nif, empresa, salario):
        super().__init__(nome, idade, nif)
        self.empresa = empresa
        self.salario = salario

    #Métodos do Empregado
    def get_empresa(self):
        return self.empresa
    def set_empresa(self,nova_empresa):
        self.empresa = nova_empresa
        return self.idade
    
    def get_salario(self):
        return self.salario
    def set_salario(self,novo_salario):
        self.salario = novo_salario
        return self.salario
    

def main():
    #Mostra contador de Pessoas
    print('Nr de Pessoas existentes:', Pessoa.mostra_ctrpessoas())
    #instanciar 2 pessoas
    p1=Pessoa('Alice', 71, 1523848125)
    print(p1.get_nome(), p1.get_idade(), p1.get_nif())
    p2=Pessoa('Jorge', 12, None)
    print(p2.get_nome(), p2.get_idade(), p2.get_nif())
    print('Nr de Pessoas chamando o método pela própria Classe:', Pessoa.mostra_ctrpessoas())
    print(f'Nr de Pessoas chamando o método pelo objeto pessoa {p2.get_nome()}:', p2.mostra_ctrpessoas())

    # Apagar pessoa p1
    del p1
    print('Nr de Pessoas chamando o método pela própria Classe:', Pessoa.mostra_ctrpessoas())


#Chamar a função principal do programa
main()
